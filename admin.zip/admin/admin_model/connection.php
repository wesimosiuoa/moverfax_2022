
<?php
// $host="localhost";
// $user="id17415443_root";
// $password="(9AP_5gbp{|@63<-";
// $dbname="id17415443_move";

$servername="localhost";
$username="root";
$password="";
$dbname="move";

$con=mysqli_connect($servername,$username,$password,$dbname);

?>
